document.write('<script src="../release/go.js"></script>');
